create
    definer = root@localhost procedure create_user_table()
BEGIN
	CREATE TABLE user(
		user_id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
		first_name VARCHAR(15) NOT NULL UNIQUE,
		last_name VARCHAR(15) NOT NULL,
		email VARCHAR(50) NOT NULL,
		date_of_birth DATE,
		active BOOLEAN DEFAULT TRUE,
		gender ENUM('Male', 'Female', 'Other') NOT NULL,
		biography TEXT,
		salary INT NOT NULL,
		started_on datetime DEFAULT CURRENT_TIMESTAMP
	);
END;

