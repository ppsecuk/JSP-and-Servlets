create
    definer = root@localhost procedure add_user(IN fName varchar(15), IN lName varchar(15), IN email varchar(30),
                                                IN dob date, IN gender varchar(10), IN bio text, IN salary int)
BEGIN
	INSERT INTO user VALUES (NULL, fName, lName, email, dob, 1, gender, bio, salary, NOW());
END;

