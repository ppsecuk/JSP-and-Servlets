create definer = root@localhost trigger add_to_history_after_update
    after UPDATE
    on user
    for each row
BEGIN
	INSERT INTO user_history
	(
		user_id, first_name, last_name, email, date_of_birth, active, gender, biography, 
		started_on, salary, type_of_modification, modified_by
	) 
	VALUES (
		OLD.user_id, OLD.first_name, OLD.last_name, OLD.email, OLD.date_of_birth, 
		OLD.active, OLD.gender, OLD.biography, OLD.started_on, OLD.salary, 'U', SESSION_USER()
	);
END;

