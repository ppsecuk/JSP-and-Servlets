create
    definer = root@localhost procedure count_users(OUT number_of_users int)
BEGIN
	SELECT COUNT(*) INTO number_of_users FROM user;
END;

