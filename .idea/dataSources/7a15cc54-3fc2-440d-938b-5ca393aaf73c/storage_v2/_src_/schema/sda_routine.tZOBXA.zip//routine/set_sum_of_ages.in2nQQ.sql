create
    definer = root@localhost procedure set_sum_of_ages(OUT sum_of_ages int)
BEGIN
	SELECT SUM(TIMESTAMPDIFF(YEAR, date_of_birth, CURRENT_TIMESTAMP)) INTO sum_of_ages FROM user;
END;

